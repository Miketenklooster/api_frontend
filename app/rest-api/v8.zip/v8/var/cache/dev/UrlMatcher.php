<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/v8/movie' => [
            [['_route' => 'app_movie_getall', '_controller' => 'App\\Controller\\MovieController::getAll'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_movie_create', '_controller' => 'App\\Controller\\MovieController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/v8/login' => [[['_route' => 'app_security_login', '_controller' => 'App\\Controller\\SecurityController::Login'], null, ['POST' => 0], null, false, false, null]],
        '/api/v8/user' => [
            [['_route' => 'app_user_getall', '_controller' => 'App\\Controller\\UserController::getAll'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_user_create', '_controller' => 'App\\Controller\\UserController::create'], null, ['POST' => 0], null, false, false, null],
        ],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/api/v8/(?'
                    .'|movie/([^/]++)(?'
                        .'|(*:70)'
                    .')'
                    .'|user/([^/]++)(?'
                        .'|(*:94)'
                    .')'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        70 => [
            [['_route' => 'app_movie_getonebyid', '_controller' => 'App\\Controller\\MovieController::getOneById'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_movie_update', '_controller' => 'App\\Controller\\MovieController::update'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_movie_delete', '_controller' => 'App\\Controller\\MovieController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        94 => [
            [['_route' => 'app_user_getonebyid', '_controller' => 'App\\Controller\\UserController::getOneById'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_user_update', '_controller' => 'App\\Controller\\UserController::update'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_user_delete', '_controller' => 'App\\Controller\\UserController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
